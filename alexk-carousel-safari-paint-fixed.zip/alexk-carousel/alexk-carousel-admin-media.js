console.log('ALEXK ✅ admin media script loaded on:', window.location.href);
