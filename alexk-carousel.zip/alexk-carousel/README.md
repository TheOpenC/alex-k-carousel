# alex-k-carousel
Application for Alex K's website.
This tool allows Alex to easily tag artwork media (documentation) to be included in a shuffled carousel. The carousel will exist on his landing page as the primary source of content for his website. As time goes on, more images will be added or removed to Alex's liking. 