<?php
/**
 * Plugin Name: Alex K - Client Image Carousel
 * Description: Adds "Include in carousel" checkbox and generates responsive JPG+WebP derivatives (Elementor-safe; Imagick-first).
 * Version: 0.2.1
 */

if (!defined('ABSPATH')) exit;

/**
 * =========
 * SETTINGS
 * =========
 * Mirrors convert-one.sh intent:
 * widths: 320 480 768 1024 1400
 * no upscaling
 * generates:
 *   <stem>-w{w}.webp / .jpg
 * and convenience siblings:
 *   <stem>.webp / .jpg (max generated)
 */
function alexk_carousel_widths(): array {
  return [320, 480, 768, 1024, 1400];
}
function alexk_carousel_meta_key(): string {
  return 'alexk_include_in_carousel';
}

/**
 * =========================
 * ADMIN: checkbox UI (Media)
 * =========================
 */
add_filter('attachment_fields_to_edit', function($form_fields, $post) {
  $key = alexk_carousel_meta_key();
  $val = get_post_meta($post->ID, $key, true);
  $checked = ($val === '1') ? 'checked' : '';

  $form_fields[$key] = [
    'label' => 'Include in carousel',
    'input' => 'html',
    'html'  => '<label class="alexk-carousel-rightside-label">
                  <input type="checkbox" class="carousel-checkbox" name="attachments['.$post->ID.']['.$key.']" value="1" '.$checked.' />
                  Include in carousel
                </label>
                <div class="alexk-carousel-checkbox-details">
                  When checked, generates responsive JPG + WebP derivatives (Elementor-safe).
                </div>',
  ];

  return $form_fields;
}, 10, 2);

add_filter('attachment_fields_to_save', function($post, $attachment) {
  $key = alexk_carousel_meta_key();
  $new = isset($attachment[$key]) && $attachment[$key] === '1' ? '1' : '0';
  $old = get_post_meta($post['ID'], $key, true);
  $old = ($old === '1') ? '1' : '0';

  update_post_meta($post['ID'], $key, $new);

  // Only act when the value changes.
  if ($new !== $old) {
    if ($new === '1') {
      alexk_generate_derivatives_for_attachment((int)$post['ID']);
    } else {
      alexk_delete_derivatives_for_attachment((int)$post['ID']);
    }
  }

  return $post;
}, 10, 2);

/**
 * =========================================
 * STOP WP PNG intermediates (upload-time)
 * =========================================
 * If you upload a PNG, WP can generate a bunch of resized PNGs.
 * Your shell workflow bypassed that — so do the same here.
 */
add_filter('intermediate_image_sizes_advanced', function($sizes, $metadata) {
  // $metadata may not include file; we’ll rely on current upload context via filter args.
  // This filter is called during metadata generation; when it's PNG, we return empty.
  // WordPress passes $metadata but not the file path; we can only do this safely by
  // also checking global $_REQUEST-ish upload state is unreliable.
  // Instead: if WP knows it's PNG at this point, it’s usually in $metadata['sizes'] pipeline,
  // but not a clean signal. We do a second filter below where we DO know the file type.
  return $sizes;
}, 10, 2);

add_filter('wp_generate_attachment_metadata', function($metadata, $attachment_id) {
  $file = get_attached_file($attachment_id);
  if (!$file || !is_string($file)) return $metadata;

  $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
  if ($ext === 'png') {
    // Remove all intermediate sizes (keeps original only).
    if (isset($metadata['sizes'])) {
      $metadata['sizes'] = [];
    }
  }
  return $metadata;
}, 10, 2);

/**
 * ===========================
 * CLEANUP on delete attachment
 * ===========================
 */
add_action('delete_attachment', function($attachment_id) {
  alexk_delete_derivatives_for_attachment((int)$attachment_id);
});

/**
 * ===========================
 * DERIVATIVE IMPLEMENTATION
 * ===========================
 */
function alexk_generate_derivatives_for_attachment(int $attachment_id): void {
  $file = get_attached_file($attachment_id);
  if (!$file || !file_exists($file)) return;

  $mime = get_post_mime_type($attachment_id);
  if (!$mime || strpos($mime, 'image/') !== 0) return;

  // Don’t try to convert SVGs, etc.
  $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
  if (in_array($ext, ['svg', 'pdf'], true)) return;

  $dir  = wp_normalize_path(dirname($file));
  $base = basename($file);
  $stem = preg_replace('/\.[^.]+$/', '', $base);

  // Get native dimensions
  $img_info = @getimagesize($file);
  if (!$img_info || empty($img_info[0]) || empty($img_info[1])) return;
  $native_w = (int)$img_info[0];
  $native_h = (int)$img_info[1];
  $native_max_edge = max($native_w, $native_h);

  $widths = alexk_carousel_widths();

  // Ensure we never upscale; if native is smaller than 1400,
  // we still create a final "-w{nativeMaxEdge}" size (like your note).
  $max_list = max($widths);
  if ($native_max_edge > 0 && $native_max_edge < $max_list) {
    $widths[] = $native_max_edge;
    $widths = array_values(array_unique($widths));
    sort($widths);
  }

  // Generate each size
  $largest_generated = 0;
  foreach ($widths as $w) {
    $w = (int)$w;
    if ($w <= 0) continue;
    if ($w > $native_max_edge) continue; // no upscaling

    $out_webp = $dir . '/' . $stem . '-w' . $w . '.webp';
    $out_jpg  = $dir . '/' . $stem . '-w' . $w . '.jpg';

    $ok_webp = alexk_imagick_resize_and_write($file, $out_webp, $w, 'webp');
    $ok_jpg  = alexk_imagick_resize_and_write($file, $out_jpg,  $w, 'jpg');

    // If Imagick isn’t available for some reason, fall back to WP editor.
    if (!$ok_webp) $ok_webp = alexk_wp_editor_resize_and_write($file, $out_webp, $w, 'image/webp', 100);
    if (!$ok_jpg)  $ok_jpg  = alexk_wp_editor_resize_and_write($file, $out_jpg,  $w, 'image/jpeg', 92);

    if ($ok_webp || $ok_jpg) {
      $largest_generated = max($largest_generated, $w);
    }
  }

  // Convenience siblings: <stem>.webp and <stem>.jpg = copy of largest generated
  if ($largest_generated > 0) {
    $src_webp = $dir . '/' . $stem . '-w' . $largest_generated . '.webp';
    $src_jpg  = $dir . '/' . $stem . '-w' . $largest_generated . '.jpg';
    $dst_webp = $dir . '/' . $stem . '.webp';
    $dst_jpg  = $dir . '/' . $stem . '.jpg';

    if (file_exists($src_webp)) @copy($src_webp, $dst_webp);
    if (file_exists($src_jpg))  @copy($src_jpg,  $dst_jpg);
  }
}

function alexk_delete_derivatives_for_attachment(int $attachment_id): void {
  $file = get_attached_file($attachment_id);
  if (!$file) return;

  $dir  = wp_normalize_path(dirname($file));
  $base = basename($file);
  $stem = preg_replace('/\.[^.]+$/', '', $base);

  // Delete the known pattern outputs
  $patterns = [
    $dir . '/' . $stem . '-w*.webp',
    $dir . '/' . $stem . '-w*.jpg',
    $dir . '/' . $stem . '.webp',
    $dir . '/' . $stem . '.jpg',
  ];

  foreach ($patterns as $pat) {
    foreach (glob($pat) ?: [] as $p) {
      if (is_file($p)) @unlink($p);
    }
  }
}

/**
 * ===========================
 * Imagick path (best for color)
 * ===========================
 * We can’t rely on a server ICC profile path like macOS,
 * but we can:
 * - auto-orient
 * - force sRGB colorspace
 * - strip profiles
 */
function alexk_imagick_resize_and_write(string $src, string $dst, int $max_edge, string $format): bool {
  if (!extension_loaded('imagick')) return false;

  try {
    $im = new Imagick();
    $im->readImage($src);

    // Normalize orientation
    if (method_exists($im, 'autoOrient')) {
      $im->autoOrient();
    }

    // Colorspace normalization (best-effort)
    if (defined('Imagick::COLORSPACE_SRGB')) {
      @ $im->setImageColorspace(Imagick::COLORSPACE_SRGB);
    }

    // Resize: constrain longest edge to $max_edge, no upscale
    $w = $im->getImageWidth();
    $h = $im->getImageHeight();
    if ($w <= 0 || $h <= 0) return false;

    $long = max($w, $h);
    if ($max_edge >= $long) {
      // no upscale: still write out? In your shell script you DO write -w{native} sometimes.
      // Here we only reach this branch if max_edge == long; so keep.
    }

    $scale = $max_edge / $long;
    $new_w = (int)round($w * $scale);
    $new_h = (int)round($h * $scale);

    $new_w = max(1, $new_w);
    $new_h = max(1, $new_h);

    $im->resizeImage($new_w, $new_h, Imagick::FILTER_LANCZOS, 1, true);

    // Strip profiles/metadata
    @ $im->stripImage();

    if ($format === 'webp') {
      $im->setImageFormat('webp');
      // Lossless isn’t perfectly standardized here; this is best-effort.
      // Quality 100 tends to preserve gradients well.
      $im->setImageCompressionQuality(100);
    } else {
      $im->setImageFormat('jpeg');
      $im->setImageCompressionQuality(92);
      // 4:4:4 sampling approximation:
      @ $im->setOption('jpeg:sampling-factor', '4:4:4');
    }

    // Ensure destination dir exists
    wp_mkdir_p(dirname($dst));

    $ok = $im->writeImage($dst);
    $im->clear();
    $im->destroy();
    return (bool)$ok;
  } catch (Throwable $e) {
    return false;
  }
}

/**
 * ===========================
 * WP image editor fallback
 * ===========================
 */
function alexk_wp_editor_resize_and_write(string $src, string $dst, int $max_edge, string $mime, int $quality): bool {
  $editor = wp_get_image_editor($src);
  if (is_wp_error($editor)) return false;

  $size = $editor->get_size();
  if (empty($size['width']) || empty($size['height'])) return false;

  $w = (int)$size['width'];
  $h = (int)$size['height'];
  $long = max($w, $h);
  if ($long <= 0) return false;

  // no upscale
  if ($max_edge > $long) $max_edge = $long;

  // Resize: preserve aspect ratio; “crop” false
  $res = $editor->resize($max_edge, $max_edge, false);
  if (is_wp_error($res)) return false;

  $editor->set_quality($quality);

  wp_mkdir_p(dirname($dst));
  $saved = $editor->save($dst, $mime);

  return (!is_wp_error($saved) && !empty($saved['path']) && file_exists($saved['path']));
}
